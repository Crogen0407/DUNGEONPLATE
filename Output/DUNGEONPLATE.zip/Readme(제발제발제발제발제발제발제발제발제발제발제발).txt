Resource/Font에 들어가서 모든 폰트 파일을 다운받으세요.

학생은 build, 쌤은 build_debug
PF스타더스트 Bold.ttf
PF스타더스트.ttf